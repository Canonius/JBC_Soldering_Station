#ifdef __IN_ECLIPSE__
//This is a automatic generated file
//Please do not modify this file
//If you touch this file your change will be overwritten during the next build
//This file has been generated on 2019-05-08 15:48:11

#include "Arduino.h"
#include <Arduino.h>
#include <Wire.h>
#include <stdint.h>
#include <avr/io.h>
#include <util/delay.h>
#include <SSD1306Ascii.h>
#include <SSD1306AsciiSpi.h>

void setup() ;
void loop() ;
void controller() ;
void ZeroCrossing() ;
void display_update() ;
void fill_buffer() ;
uint16_t poti_scale(uint16_t adc_value) ;
void heater_on_req(void) ;
void heater_control(void) ;
void heater_on(uint8_t heater) ;
void heater_off(uint8_t heater) ;
void LM73_config(void) ;
uint16_t LM73_get_temp(void) ;
void check_sleep() ;
void ADS1115_singleshot(int ch) ;
int16_t ADS1115_get_temp(int ch) ;
void ADS1115_set_RDY_PIN(void) ;

#include "JBC_Station.ino"


#endif
